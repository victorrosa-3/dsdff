# Control de Versiones con Git y GitHub

Proyecto del **Examen Práctico 2**. En este repositorio practicamos el uso de Git y GitHub
para registrar cambios en archivos y trabajar de forma colaborativa.

## Integrantes
- Integrante 1
- Integrante 2

## Comandos usados
`git init`, `git add`, `git commit`, `git status`, `git log`, `git push`
